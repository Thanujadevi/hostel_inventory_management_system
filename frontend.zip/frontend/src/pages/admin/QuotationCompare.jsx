import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { StatusBadge } from '../../components/common/StatusBadge';
import { 
  GitCompare, 
  Award, 
  Truck, 
  Calendar, 
  Trophy, 
  CheckCircle2, 
  ShoppingCart,
  Check,
  X,
  User,
  Phone,
  Mail,
  FileText,
  Star,
  MapPin,
  Building2,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Layers,
  Info,
  DollarSign,
  PackageCheck
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { apiService } from '../../services/api';

export const AdminQuotationCompare = () => {
  const { requests, quotations, purchases, suppliers, updateRequestStatus, refreshAll, mockApi, showToast } = useData();
  const { user } = useAuth();
  const activeUser = user?.name || user?.username || 'Chief Warden / Admin';

  // Filter state for requirement list: 'OPEN' (unawarded), 'AWARDED' (PO issued), 'ALL'
  const [filterTab, setFilterTab] = useState('OPEN');
  // Month Cycle Filter State (e.g., 'ALL', 'August 2026', 'September 2026')
  const [filterMonth, setFilterMonth] = useState('ALL');
  // View mode switcher: 'cards' (Supplier Bid Cards), 'matrix' (Item-wise Comparison), 'inspector' (Detailed Inspector)
  const [viewMode, setViewMode] = useState('cards');

  // Extract unique Month & Year options from requests list
  const availableMonths = useMemo(() => {
    const periodSet = new Set();
    (requests || []).forEach(r => {
      const month = r.txt_Month || 'August';
      const year = r.int_Year || 2026;
      periodSet.add(`${month} ${year}`);
    });
    return Array.from(periodSet);
  }, [requests]);

  // Filter requests based on selected filterTab & filterMonth (Only Admin-Approved & Supplier-Quoted requests appear)
  const filteredRequests = useMemo(() => {
    return requests.filter(r => {
      const status = (r.txt_Status || '').toLowerCase();
      const isApprovedByAdmin = !['pending', 'pending approval'].includes(status);
      const isProcessed = ['po issued', 'delivered', 'completed', 'dispatched', 'shipped'].includes(status);
      const hasPO = (purchases || []).some(p => 
        Number(p.int_Request_Id) === Number(r.int_Request_Id) ||
        String(p.request_no) === String(r.txt_Request_No || r.txt_Request_Code)
      );
      const isAwarded = isProcessed || hasPO;
      const hasSupplierQuotes = (quotations || []).some(q => 
        Number(q.int_Request_Id) === Number(r.int_Request_Id)
      );

      // Filter by Month Cycle
      if (filterMonth !== 'ALL') {
        const reqPeriod = `${r.txt_Month || 'August'} ${r.int_Year || 2026}`;
        if (reqPeriod !== filterMonth) return false;
      }

      if (filterTab === 'OPEN') return isApprovedByAdmin && !isAwarded && hasSupplierQuotes;
      if (filterTab === 'AWARDED') return isAwarded;
      return isApprovedByAdmin && hasSupplierQuotes; // 'ALL' supplier-quoted requests
    });
  }, [requests, purchases, quotations, filterTab, filterMonth]);

  // Group filtered requests into Consolidated Monthly Batches (1 master entry per Month/Year)
  const consolidatedMonthlyBatches = useMemo(() => {
    const batchesMap = new Map();

    filteredRequests.forEach(req => {
      const monthStr = req.txt_Month || 'August';
      const yearVal = req.int_Year || 2026;
      const monthKey = `${monthStr} ${yearVal}`;

      if (!batchesMap.has(monthKey)) {
        batchesMap.set(monthKey, {
          monthKey,
          txt_Month: monthStr,
          int_Year: yearVal,
          primaryReqId: req.int_Request_Id,
          requestIds: [req.int_Request_Id],
          requests: [req],
          requestCodes: [req.txt_Request_No || `REQ-${String(req.int_Request_Id).padStart(4, '0')}`],
          txt_Status: req.txt_Status || 'Open for Quotation'
        });
      } else {
        const batch = batchesMap.get(monthKey);
        batch.requestIds.push(req.int_Request_Id);
        batch.requests.push(req);
        batch.requestCodes.push(req.txt_Request_No || `REQ-${String(req.int_Request_Id).padStart(4, '0')}`);
      }
    });

    return Array.from(batchesMap.values()).map(batch => {
      // Merge all items from all store requests in this month
      const itemMap = new Map();
      batch.requests.forEach(r => {
        (r.items || []).forEach(item => {
          const pId = Number(item.int_Product_Id || item.int_Item_Id);
          const pName = item.txt_Product_Name || item.txt_Item_Name || `Product #${pId}`;
          const pCategory = item.txt_Category || item.category || 'General';
          const pUnit = item.txt_Unit || item.unit || 'Kg';
          const qty = Number(item.dec_Required_Qty || item.int_Requested_Quantity || item.int_Quantity || item.quantity || 0);

          if (!itemMap.has(pId)) {
            itemMap.set(pId, {
              ...item,
              int_Product_Id: pId,
              txt_Product_Name: pName,
              txt_Category: pCategory,
              txt_Unit: pUnit,
              dec_Required_Qty: qty
            });
          } else {
            const existing = itemMap.get(pId);
            existing.dec_Required_Qty += qty;
          }
        });
      });

      const consolidatedItems = Array.from(itemMap.values());
      const batchQuotations = quotations.filter(q => batch.requestIds.includes(Number(q.int_Request_Id)));

      return {
        ...batch,
        int_Request_Id: batch.primaryReqId,
        txt_Request_No: `Master (${batch.monthKey})`,
        items: consolidatedItems,
        totalItemsCount: consolidatedItems.length,
        quotationCount: batchQuotations.length,
        txt_Request_No_Summary: batch.requestCodes.join(', ')
      };
    });
  }, [filteredRequests, quotations]);

  // Selected month key state (e.g. 'August 2026')
  const [selectedMonthKey, setSelectedMonthKey] = useState('');

  // Auto-select first month batch when filter tab changes or data loads
  useEffect(() => {
    if (consolidatedMonthlyBatches.length > 0) {
      const exists = consolidatedMonthlyBatches.some(b => b.monthKey === selectedMonthKey);
      if (!exists) {
        setSelectedMonthKey(consolidatedMonthlyBatches[0].monthKey);
      }
    } else {
      setSelectedMonthKey('');
    }
  }, [consolidatedMonthlyBatches, selectedMonthKey]);

  const currentReq = useMemo(() => {
    if (!consolidatedMonthlyBatches || consolidatedMonthlyBatches.length === 0) return null;
    return consolidatedMonthlyBatches.find(b => b.monthKey === selectedMonthKey) || consolidatedMonthlyBatches[0] || null;
  }, [consolidatedMonthlyBatches, selectedMonthKey]);

  const isOrderPlaced = useMemo(() => {
    if (!currentReq) return false;
    const reqStatus = String(currentReq.txt_Status || '').toLowerCase();
    if (['po issued', 'delivered', 'completed', 'dispatched', 'shipped'].includes(reqStatus)) return true;

    return (purchases || []).some(p => 
      (currentReq.requestIds || [currentReq.int_Request_Id]).some(rId => Number(p.int_Request_Id) === Number(rId)) ||
      String(p.request_no) === String(currentReq.txt_Request_No || currentReq.txt_Request_Code)
    );
  }, [currentReq, purchases]);

  const awardedPO = useMemo(() => {
    if (!currentReq || !purchases) return null;
    return purchases.find(p => 
      (currentReq.requestIds || [currentReq.int_Request_Id]).some(rId => Number(p.int_Request_Id) === Number(rId)) ||
      String(p.request_no) === String(currentReq.txt_Request_No || currentReq.txt_Request_Code)
    );
  }, [currentReq, purchases]);

  // All items requested in current consolidated batch
  const activeReqItems = useMemo(() => {
    return currentReq?.items || [];
  }, [currentReq]);

  // Pagination state for product items comparison matrix table
  const [itemsPage, setItemsPage] = useState(1);
  const [itemsPageSize, setItemsPageSize] = useState(5);

  useEffect(() => {
    setItemsPage(1);
  }, [selectedMonthKey, itemsPageSize]);

  const totalReqItems = activeReqItems.length;
  const itemsTotalPages = Math.ceil(totalReqItems / itemsPageSize) || 1;
  const itemsStartIndex = (itemsPage - 1) * itemsPageSize;
  const paginatedReqItems = useMemo(() => {
    return activeReqItems.slice(itemsStartIndex, itemsStartIndex + itemsPageSize);
  }, [activeReqItems, itemsStartIndex, itemsPageSize]);

  // Retrieve raw quotations for current selected monthly batch
  const reqQuotations = useMemo(() => {
    if (!currentReq) return [];
    const reqIds = currentReq.requestIds || [Number(currentReq.int_Request_Id)];
    const rawQuotes = quotations.filter(q => reqIds.includes(Number(q.int_Request_Id)));
    const supplierMap = new Map();
    
    rawQuotes.forEach(q => {
      const sId = q.int_Supplier_Id || q.supplier_name || q.txt_Supplier_Name || q.int_Quotation_Id;
      if (!supplierMap.has(sId)) {
        supplierMap.set(sId, q);
      } else {
        const existing = supplierMap.get(sId);
        if (Number(q.int_Quotation_Id) > Number(existing.int_Quotation_Id)) {
          supplierMap.set(sId, q);
        }
      }
    });

    return Array.from(supplierMap.values());
  }, [quotations, currentReq]);

  // Compute detailed statistics, breakdown, and Grand Total for each quotation
  const sortedQuotations = useMemo(() => {
    if (!currentReq) return [];
    const reqItemCount = currentReq?.items?.length || 0;

    const computed = reqQuotations.map(q => {
      let availableItemsCount = 0;
      let itemsSubtotal = 0;
      const missingItems = [];

      (currentReq?.items || []).forEach(reqItem => {
        const reqPId = Number(reqItem.int_Product_Id || reqItem.int_Item_Id);
        const qItem = q.items?.find(i => Number(i.int_Product_Id || i.int_Item_Id) === reqPId);
        const price = Number(qItem?.dec_Unit_Price ?? qItem?.dbl_Unit_Price ?? qItem?.unit_price ?? 0);
        const isAvail = qItem && qItem.is_available !== false && qItem.txt_Status !== 'Not Available' && price > 0;
        const reqQty = Number(reqItem.dec_Required_Qty || reqItem.int_Requested_Quantity || reqItem.int_Quantity || reqItem.quantity || 1);

        if (isAvail) {
          availableItemsCount++;
          itemsSubtotal += price * reqQty;
        } else {
          missingItems.push(reqItem);
        }
      });

      const coveragePercent = reqItemCount > 0 ? Math.round((availableItemsCount / reqItemCount) * 100) : 100;
      const transport = Number(q.dec_Transport_Cost ?? q.dbl_Transport_Cost ?? q.transportCost ?? 0);
      const deliveryDays = q.txt_Delivery_Days || (q.int_Delivery_Days ? `${q.int_Delivery_Days} Days` : '3 Days');
      const grandTotal = itemsSubtotal > 0 ? (itemsSubtotal + transport) : Number(q.dec_Total_Amount ?? q.dbl_Total_Amount ?? 0);

      // Resolve supplier record details dynamically from database
      const sup = (suppliers || []).find(s => Number(s.int_Supplier_Id) === Number(q.int_Supplier_Id));
      const supplierName = sup?.txt_Store_Name || sup?.txt_Supplier_Name || q.supplier_name || q.txt_Store_Name || q.txt_Supplier_Name || `Supplier #${q.int_Supplier_Id || ''}`;
      const ownerName = sup?.txt_Owner_Name || sup?.txt_Contact_Person || q.supplier_owner || q.txt_Owner_Name || q.txt_Contact_Person || '';
      const phone = sup?.txt_Phone || q.supplier_phone || q.txt_Phone || '';
      const email = sup?.txt_Email || q.supplier_email || q.txt_Email || '';
      const gst = sup?.txt_GST_Number || sup?.txt_GSTIN || q.supplier_gst || q.txt_GST_Number || q.txt_GSTIN || '';
      const rating = Number(sup?.dbl_Rating ?? q.supplier_rating ?? q.dbl_Rating ?? 0);
      const cityState = (sup?.txt_City && sup?.txt_State)
        ? `${sup.txt_City}, ${sup.txt_State}`
        : (sup?.txt_City || sup?.txt_State || q.supplier_city || q.supplier_state || '');

      return {
        ...q,
        totalReqItems: reqItemCount,
        availableItemsCount,
        missingItems,
        coveragePercent,
        isFullCoverage: availableItemsCount === reqItemCount,
        itemsSubtotal,
        transport,
        deliveryDays,
        grandTotal,
        supplierName,
        ownerName,
        phone,
        email,
        gst,
        rating,
        cityState
      };
    });

    // Sort: Full coverage first, then highest coverage %, then lowest total bid price (L1)
    return computed.sort((a, b) => {
      if (a.isFullCoverage !== b.isFullCoverage) {
        return a.isFullCoverage ? -1 : 1;
      }
      if (a.coveragePercent !== b.coveragePercent) {
        return b.coveragePercent - a.coveragePercent;
      }
      return a.grandTotal - b.grandTotal;
    });
  }, [reqQuotations, currentReq, suppliers]);

  // Overall Lowest Price (L1) Recommendation
  const optimumQuotation = sortedQuotations.length > 0 ? sortedQuotations[0] : null;
  const highestQuotation = sortedQuotations.length > 1 ? sortedQuotations[sortedQuotations.length - 1] : null;

  const costSavings = optimumQuotation && highestQuotation 
    ? (highestQuotation.grandTotal - optimumQuotation.grandTotal) 
    : 0;

  // Selected supplier for Inspector View
  const [inspectorSupplierId, setInspectorSupplierId] = useState('');
  const activeInspectorQuote = useMemo(() => {
    if (!sortedQuotations.length) return null;
    return sortedQuotations.find(q => String(q.int_Supplier_Id) === String(inspectorSupplierId)) || sortedQuotations[0];
  }, [sortedQuotations, inspectorSupplierId]);

  // Award PO to a specific single supplier
  const handleAwardPO = async (quotationId, supplierName) => {
    if (window.confirm(`Accept price quote from ${supplierName} and issue official Purchase Order?`)) {
      try {
        const quo = quotations.find(q => Number(q.int_Quotation_Id) === Number(quotationId));
        const finalTotal = Number(quo?.dec_Total_Amount || quo?.grandTotal || 0) + Number(quo?.dec_Transport_Cost || quo?.transport || 0);
        const poData = {
          int_Quotation_Id: quotationId,
          int_Request_Id: quo?.int_Request_Id || currentReq?.int_Request_Id,
          int_Supplier_Id: quo?.int_Supplier_Id || 1,
          int_Store_Id: currentReq?.int_Store_Id || 1,
          dbl_Total_Amount: finalTotal > 0 ? finalTotal : 5000,
          txt_Status: 'PO Issued',
          txt_Created_By: activeUser,
          txt_Updated_By: activeUser
        };
        try {
          await apiService.savePurchase(poData);
        } catch (e) {
          await mockApi.approveQuotationAndGeneratePO(quotationId);
        }

        // Update requirement status in backend database
        if (currentReq?.int_Request_Id && updateRequestStatus) {
          try {
            await updateRequestStatus(currentReq.int_Request_Id, 'PO Issued', `Purchase Order issued to ${supplierName}`);
          } catch (e) {}
        }

        showToast(`Price quote accepted! Order sent to ${supplierName} for delivery.`, 'success');
        await refreshAll();
      } catch (err) {
        console.error("Error approving quotation:", err);
        showToast("Failed to place Purchase Order", "error");
      }
    }
  };

  // Award Split PO across multiple suppliers (Item-wise L1)
  const handleAwardSplitPO = async () => {
    if (!currentReq || !sortedQuotations || sortedQuotations.length === 0) return;

    if (!window.confirm("Split order between suppliers based on item-wise lowest price (Item L1)? System will create separate Purchase Orders for each supplier.")) {
      return;
    }

    try {
      const supplierItemMap = new Map();

      (currentReq.items || []).forEach(reqItem => {
        const reqPId = Number(reqItem.int_Product_Id || reqItem.int_Item_Id);
        let bestQuote = null;
        let lowestPrice = Infinity;

        sortedQuotations.forEach(q => {
          const qItem = q.items?.find(i => Number(i.int_Product_Id || i.int_Item_Id) === reqPId);
          const price = Number(qItem?.dec_Unit_Price ?? qItem?.dbl_Unit_Price ?? qItem?.unit_price ?? 0);
          const isAvail = qItem && qItem.is_available !== false && qItem.txt_Status !== 'Not Available' && price > 0;

          if (isAvail && price < lowestPrice) {
            lowestPrice = price;
            bestQuote = q;
          }
        });

        if (bestQuote) {
          const sId = bestQuote.int_Supplier_Id;
          const reqQty = Number(reqItem.dec_Required_Qty || reqItem.int_Requested_Quantity || reqItem.int_Quantity || reqItem.quantity || 1);
          const lineTotal = lowestPrice * reqQty;

          if (!supplierItemMap.has(sId)) {
            supplierItemMap.set(sId, {
              supplierId: sId,
              supplierName: bestQuote.supplierName,
              quotationId: bestQuote.int_Quotation_Id,
              items: [reqItem],
              totalAmount: lineTotal + Number(bestQuote.transport || 0)
            });
          } else {
            const existing = supplierItemMap.get(sId);
            existing.items.push(reqItem);
            existing.totalAmount += lineTotal;
          }
        }
      });

      if (supplierItemMap.size === 0) {
        showToast("No valid supplier price quotes available for item split.", "error");
        return;
      }

      let poCount = 0;
      const supplierNames = [];

      for (const [sId, group] of supplierItemMap.entries()) {
        const poData = {
          int_Quotation_Id: group.quotationId,
          int_Request_Id: currentReq.int_Request_Id,
          int_Supplier_Id: sId,
          int_Store_Id: currentReq.int_Store_Id || 1,
          dbl_Total_Amount: group.totalAmount,
          txt_Status: 'PO Issued',
          txt_Created_By: activeUser,
          txt_Updated_By: activeUser
        };

        try {
          await apiService.savePurchase(poData);
        } catch (e) {
          await mockApi.approveQuotationAndGeneratePO(group.quotationId);
        }
        poCount++;
        supplierNames.push(group.supplierName);
      }

      if (currentReq?.int_Request_Id && updateRequestStatus) {
        try {
          await updateRequestStatus(currentReq.int_Request_Id, 'PO Issued', `Split Purchase Orders issued across ${poCount} suppliers`);
        } catch (e) {}
      }

      showToast(`Split Orders Placed! ${poCount} Purchase Orders issued to: ${supplierNames.join(', ')}.`, 'success');
      await refreshAll();
    } catch (err) {
      console.error("Error creating split purchase orders:", err);
      showToast("Failed to create split purchase orders", "error");
    }
  };

  const handleRejectRequest = async (requestId) => {
    if (window.confirm("Are you sure you want to reject and delete this request from database?")) {
      try {
        await apiService.deleteRequest(requestId);
        showToast("Request rejected and removed!", "info");
        await refreshAll();
      } catch (err) {
        showToast("Failed to delete request", "error");
      }
    }
  };

  return (
    <div style={{ maxWidth: '1240px', margin: '0 auto', paddingBottom: '40px' }}>
      {/* Page Header */}
      <div className="page-header" style={{ marginBottom: '20px' }}>
        <div>
          <h1 style={{ margin: 0, fontSize: '1.45rem', fontWeight: 800, color: 'var(--color-text-primary)' }}>
            Compare Price Quotes & Award Orders
          </h1>
          <p style={{ color: 'var(--color-text-secondary)', fontSize: '0.875rem', marginTop: '3px', margin: 0 }}>
            Review supplier bids, evaluate item-wise prices, and issue Purchase Orders to the lowest bidder (L1).
          </p>
        </div>
      </div>

      {/* Controls & Filter Bar */}
      <div className="card" style={{ marginBottom: '24px', padding: '18px 22px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Top Row: Requirement Status Tabs & Consolidated Monthly Requisition Dropdown */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '14px' }}>
            {/* Filter Tabs */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', backgroundColor: 'var(--color-bg-secondary, #f1f5f9)', padding: '4px', borderRadius: '8px' }}>
              <button
                type="button"
                className={`btn btn-sm ${filterTab === 'OPEN' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setFilterTab('OPEN')}
                style={{ borderRadius: '6px', fontWeight: 600, border: 'none' }}
              >
                Open Bids ({requests.filter(r => !['approved','po issued','delivered','completed','rejected'].includes((r.txt_Status||'').toLowerCase())).length})
              </button>
              <button
                type="button"
                className={`btn btn-sm ${filterTab === 'AWARDED' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setFilterTab('AWARDED')}
                style={{ borderRadius: '6px', fontWeight: 600, border: 'none' }}
              >
                Awarded Orders
              </button>
              <button
                type="button"
                className={`btn btn-sm ${filterTab === 'ALL' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setFilterTab('ALL')}
                style={{ borderRadius: '6px', fontWeight: 600, border: 'none' }}
              >
                All Monthly Requisitions ({requests.length})
              </button>
            </div>

            {/* Consolidated Monthly Requisition Selector Dropdown */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, maxWidth: '620px', minWidth: '300px' }}>
              <label className="form-label" style={{ margin: 0, whiteSpace: 'nowrap', fontWeight: 700, fontSize: '0.875rem', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <Calendar size={16} /> Select Consolidated Month:
              </label>
              <select
                className="form-select"
                style={{ fontWeight: 600, fontSize: '0.875rem', width: '100%', borderRadius: '8px' }}
                value={selectedMonthKey}
                onChange={e => setSelectedMonthKey(e.target.value)}
              >
                {consolidatedMonthlyBatches.length === 0 ? (
                  <option value="">No matching monthly requisitions found</option>
                ) : (
                  consolidatedMonthlyBatches.map(batch => (
                    <option key={batch.monthKey} value={batch.monthKey}>
                      📅 {batch.monthKey} — Master Consolidated Requisition ({batch.totalItemsCount} Products | {batch.quotationCount} Bids)
                    </option>
                  ))
                )}
              </select>
            </div>

            {currentReq && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <StatusBadge status={(isOrderPlaced || awardedPO) ? 'PO Issued' : currentReq.txt_Status} />
                <button
                  type="button"
                  className="btn btn-danger btn-sm"
                  onClick={() => handleRejectRequest(currentReq.int_Request_Id)}
                  style={{ display: 'flex', alignItems: 'center', gap: '4px', backgroundColor: '#ef4444', color: '#fff', border: 'none', padding: '6px 12px', fontSize: '0.8rem', fontWeight: 600, borderRadius: '6px' }}
                  title="Delete requirement record from database"
                >
                  <X size={14} /> Reject
                </button>
              </div>
            )}
          </div>

          {/* Quick Metrics Bar for Selected Consolidated Requisition */}
          {currentReq && (
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
              gap: '12px',
              paddingTop: '12px',
              borderTop: '1px dashed var(--color-border)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ backgroundColor: 'rgba(2, 132, 199, 0.1)', color: 'var(--color-primary)', padding: '8px', borderRadius: '8px' }}>
                  <Calendar size={18} />
                </div>
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--color-text-secondary)', textTransform: 'uppercase', fontWeight: 700 }}>Requisition Period</div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--color-primary)' }}>{currentReq.txt_Month || 'August'} {currentReq.int_Year || 2026} Batch</div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', color: '#059669', padding: '8px', borderRadius: '8px' }}>
                  <Layers size={18} />
                </div>
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--color-text-secondary)', textTransform: 'uppercase', fontWeight: 700 }}>Consolidated Items</div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--color-text-primary)' }}>{currentReq.items?.length || 0} Products Total</div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ backgroundColor: 'rgba(168, 85, 247, 0.1)', color: '#9333ea', padding: '8px', borderRadius: '8px' }}>
                  <GitCompare size={18} />
                </div>
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--color-text-secondary)', textTransform: 'uppercase', fontWeight: 700 }}>Supplier Bids</div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 800, color: '#9333ea' }}>{reqQuotations.length} Quotes Submitted</div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ backgroundColor: 'rgba(234, 179, 8, 0.1)', color: '#b45309', padding: '8px', borderRadius: '8px' }}>
                  <Trophy size={18} />
                </div>
                <div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--color-text-secondary)', textTransform: 'uppercase', fontWeight: 700 }}>Lowest Bid (L1)</div>
                  <div style={{ fontSize: '0.9rem', fontWeight: 800, color: optimumQuotation ? '#047857' : 'var(--color-text-secondary)' }}>
                    {optimumQuotation ? `₹${optimumQuotation.grandTotal.toLocaleString('en-IN')}` : 'No Bids'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      {!currentReq ? (
        <div className="card" style={{ padding: '48px 20px', textAlign: 'center' }}>
          <CheckCircle2 size={48} color="var(--color-success-text)" style={{ marginBottom: '14px' }} />
          <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>No Requirements Found</h3>
          <p style={{ fontSize: '0.875rem', color: 'var(--color-text-secondary)', marginTop: '6px', maxWidth: '500px', margin: '6px auto 0' }}>
            There are currently no requirements matching your filter criteria. Switch to "All Requirements" or check back later when store managers raise new requirements.
          </p>
        </div>
      ) : reqQuotations.length === 0 ? (
        <div className="card" style={{ padding: '48px 24px', textAlign: 'center' }}>
          <GitCompare size={44} color="var(--color-text-muted)" style={{ marginBottom: '14px', opacity: 0.5 }} />
          <h3 style={{ fontSize: '1.15rem', fontWeight: 800 }}>No Supplier Quotes Received Yet</h3>
          <p style={{ fontSize: '0.875rem', color: 'var(--color-text-secondary)', marginTop: '6px', maxWidth: '520px', margin: '6px auto 0' }}>
            Registered suppliers have been notified for <strong>{currentReq.txt_Request_No}</strong>. As soon as suppliers submit their price bids in their portal, they will automatically appear here for real-time comparison.
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Overall Lowest Price (L1) Recommendation Card */}
          {optimumQuotation && (
            <div className="card" style={{
              backgroundColor: 'var(--color-surface, #ffffff)',
              border: '1px solid var(--color-border)',
              borderLeft: '5px solid #059669',
              borderRadius: '12px',
              padding: '20px 24px',
              boxShadow: 'var(--shadow-sm)'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px' }}>
                  <div style={{
                    backgroundColor: '#ecfdf5',
                    color: '#059669',
                    padding: '12px',
                    borderRadius: '10px',
                    border: '1px solid #a7f3d0',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0
                  }}>
                    <Trophy size={26} />
                  </div>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                      <span style={{
                        fontSize: '0.72rem',
                        fontWeight: 800,
                        textTransform: 'uppercase',
                        color: '#047857',
                        backgroundColor: '#e6f4ea',
                        border: '1px solid #a7f3d0',
                        padding: '3px 10px',
                        borderRadius: '12px',
                        letterSpacing: '0.5px'
                      }}>
                        Lowest Bidder (L1)
                      </span>
                      <span style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--color-text-secondary)', backgroundColor: 'var(--color-bg-secondary, #f1f5f9)', padding: '2px 8px', borderRadius: '10px' }}>
                        Coverage: {optimumQuotation.availableItemsCount}/{optimumQuotation.totalReqItems} ({optimumQuotation.coveragePercent}%)
                      </span>
                    </div>

                    <h3 style={{ margin: '6px 0 3px 0', fontSize: '1.2rem', fontWeight: 800, color: 'var(--color-text-primary)', display: 'flex', alignItems: 'center', gap: '10px' }}>
                      {optimumQuotation.supplierName}
                      {optimumQuotation.ownerName && (
                        <span style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--color-text-secondary)' }}>
                          ({optimumQuotation.ownerName})
                        </span>
                      )}
                    </h3>

                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', fontSize: '0.8125rem', color: 'var(--color-text-secondary)', marginTop: '4px' }}>
                      {optimumQuotation.phone && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontWeight: 600 }}>
                          <Phone size={14} /> {optimumQuotation.phone}
                        </span>
                      )}
                      {optimumQuotation.email && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Mail size={14} /> {optimumQuotation.email}
                        </span>
                      )}
                      {optimumQuotation.gst && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontWeight: 700, fontFamily: 'monospace' }}>
                          <FileText size={14} /> GST: {optimumQuotation.gst}
                        </span>
                      )}
                      {optimumQuotation.rating > 0 && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '3px', fontWeight: 700, color: '#b45309' }}>
                          <Star size={14} fill="#f59e0b" color="#f59e0b" /> {optimumQuotation.rating.toFixed(1)} / 5.0
                        </span>
                      )}
                    </div>

                    <div style={{ margin: '8px 0 0 0', fontSize: '0.875rem', color: 'var(--color-text-secondary)' }}>
                      Total Bid Price: <strong style={{ color: 'var(--color-text-primary)', fontSize: '1.15rem' }}>₹{optimumQuotation.grandTotal.toLocaleString('en-IN')}</strong>
                      <span style={{ opacity: 0.85, marginLeft: '8px', fontSize: '0.8rem' }}>
                        (Products: ₹{optimumQuotation.itemsSubtotal.toLocaleString('en-IN')} + Freight: ₹{optimumQuotation.transport.toLocaleString('en-IN')} | Turnaround: {optimumQuotation.deliveryDays})
                      </span>
                      {costSavings > 0 && (
                        <span style={{ fontWeight: 700, color: '#047857', backgroundColor: '#e6f4ea', padding: '2px 8px', borderRadius: '6px', marginLeft: '10px', fontSize: '0.78rem' }}>
                          Save ₹{costSavings.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', alignItems: 'center' }}>
                  {isOrderPlaced || awardedPO || optimumQuotation.txt_Status === 'Approved' ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#047857', fontWeight: 800, fontSize: '0.95rem', backgroundColor: '#e6f4ea', padding: '8px 16px', borderRadius: '8px' }}>
                      <CheckCircle2 size={20} /> Order Awarded & PO Issued
                    </div>
                  ) : (
                    <>
                      <button
                        className="btn btn-primary"
                        onClick={() => handleAwardPO(optimumQuotation.int_Quotation_Id, optimumQuotation.supplierName)}
                        style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', fontWeight: 700, fontSize: '0.875rem', borderRadius: '8px' }}
                      >
                        <ShoppingCart size={17} /> Accept Recommended Quote (L1)
                      </button>
                      {sortedQuotations.length > 1 && (
                        <button
                          className="btn btn-secondary"
                          onClick={handleAwardSplitPO}
                          style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', fontWeight: 700, fontSize: '0.875rem', borderRadius: '8px' }}
                          title="Split order across multiple suppliers based on item-wise lowest price (Item L1)"
                        >
                          <Award size={17} /> Split Order (Item L1)
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* View Mode Switcher Tabs */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '2px solid var(--color-border)', paddingBottom: '8px' }}>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                type="button"
                className={`btn btn-sm ${viewMode === 'cards' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setViewMode('cards')}
                style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, padding: '8px 16px' }}
              >
                <Layers size={16} /> Supplier Bids ({sortedQuotations.length})
              </button>
              <button
                type="button"
                className={`btn btn-sm ${viewMode === 'matrix' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setViewMode('matrix')}
                style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, padding: '8px 16px' }}
              >
                <GitCompare size={16} /> Item Price Matrix
              </button>
              <button
                type="button"
                className={`btn btn-sm ${viewMode === 'inspector' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setViewMode('inspector')}
                style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 700, padding: '8px 16px' }}
              >
                <FileText size={16} /> Quote Inspector
              </button>
            </div>
          </div>

          {/* MODE 1: SUPPLIER BIDS SUMMARY TABLE */}
          {viewMode === 'cards' && (
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '14px 20px', backgroundColor: 'var(--color-bg-secondary, #f8fafc)', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 800, color: 'var(--color-text-primary)' }}>Supplier Bids Overview</h3>
                <span style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', fontWeight: 600 }}>
                  {sortedQuotations.length} Bidding Supplier(s) Evaluated
                </span>
              </div>

              <div className="table-container" style={{ overflowX: 'auto' }}>
                <table className="table" style={{ fontSize: '0.875rem', marginBottom: 0 }}>
                  <thead>
                    <tr>
                      <th style={{ backgroundColor: '#f8fafc', padding: '12px 16px' }}>Rank & Supplier Name</th>
                      <th style={{ backgroundColor: '#f8fafc', padding: '12px 16px' }}>Contact & GSTIN</th>
                      <th style={{ backgroundColor: '#f8fafc', padding: '12px 16px' }}>Products Quoted</th>
                      <th style={{ backgroundColor: '#f8fafc', padding: '12px 16px' }}>Turnaround</th>
                      <th style={{ backgroundColor: '#f8fafc', padding: '12px 16px' }}>Freight (₹)</th>
                      <th style={{ backgroundColor: '#f8fafc', padding: '12px 16px' }}>Total Bid Amount</th>
                      <th style={{ backgroundColor: '#f8fafc', padding: '12px 16px', textAlign: 'center' }}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedQuotations.map((q, rankIdx) => {
                      const isL1 = rankIdx === 0;
                      return (
                        <tr key={q.int_Quotation_Id} style={{ backgroundColor: 'transparent' }}>
                          <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <span style={{
                                fontSize: '0.65rem',
                                fontWeight: 800,
                                textTransform: 'uppercase',
                                color: '#ffffff',
                                backgroundColor: isL1 ? '#2563eb' : '#64748b',
                                padding: '3px 9px',
                                borderRadius: '10px'
                              }}>
                                {isL1 ? 'L1 Lowest Bid' : `Rank #${rankIdx + 1}`}
                              </span>
                              <strong style={{ fontSize: '0.95rem', color: 'var(--color-text-primary)' }}>{q.supplierName}</strong>
                            </div>
                          </td>
                          <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>
                            <div style={{ fontSize: '0.825rem', fontWeight: 600 }}>{q.ownerName || '—'}</div>
                            {q.gst && <div style={{ fontSize: '0.75rem', fontFamily: 'monospace', color: 'var(--color-text-secondary)' }}>GST: {q.gst}</div>}
                          </td>
                          <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>
                            <span style={{ fontWeight: 600, color: 'var(--color-text-primary)' }}>
                              {q.availableItemsCount}/{q.totalReqItems} Items ({q.coveragePercent}%)
                            </span>
                          </td>
                          <td style={{ padding: '12px 16px', verticalAlign: 'middle', fontWeight: 600 }}>{q.deliveryDays}</td>
                          <td style={{ padding: '12px 16px', verticalAlign: 'middle', fontWeight: 600 }}>₹{q.transport}</td>
                          <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>
                            <div style={{ fontWeight: 800, fontSize: '1rem', color: 'var(--color-text-primary)' }}>
                              ₹{q.grandTotal.toLocaleString('en-IN')}
                            </div>
                          </td>
                          <td style={{ padding: '12px 16px', verticalAlign: 'middle', textAlign: 'center' }}>
                            {isOrderPlaced || awardedPO ? (
                              (awardedPO && (awardedPO.int_Quotation_Id ? Number(q.int_Quotation_Id) === Number(awardedPO.int_Quotation_Id) : Number(q.int_Supplier_Id) === Number(awardedPO.int_Supplier_Id))) ? (
                                <span style={{ color: '#047857', fontWeight: 800, fontSize: '0.85rem', backgroundColor: '#e6f4ea', border: '1px solid #a7f3d0', padding: '4px 12px', borderRadius: '12px' }}>
                                  ✓ PO Awarded (Winner)
                                </span>
                              ) : (
                                <span style={{ color: '#64748b', fontWeight: 600, fontSize: '0.825rem', backgroundColor: '#f1f5f9', padding: '4px 10px', borderRadius: '12px' }}>
                                  Not Selected
                                </span>
                              )
                            ) : currentReq?.txt_Status?.toLowerCase() === 'rejected' ? (
                              <span style={{ color: '#ef4444', fontWeight: 700, fontSize: '0.825rem', backgroundColor: '#fef2f2', border: '1px solid #fecaca', padding: '4px 10px', borderRadius: '12px' }}>
                                Request Rejected
                              </span>
                            ) : (
                              <button
                                type="button"
                                className={isL1 ? "btn btn-primary btn-sm" : "btn btn-secondary btn-sm"}
                                onClick={() => handleAwardPO(q.int_Quotation_Id, q.supplierName)}
                                style={{ fontWeight: 700, padding: '7px 16px', borderRadius: '6px', whiteSpace: 'nowrap' }}
                              >
                                Accept {q.supplierName}'s Bid
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* MODE 2: ITEM-BY-ITEM COMPARISON MATRIX */}
          {viewMode === 'matrix' && (
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '14px 20px', backgroundColor: 'var(--color-bg-secondary, #f8fafc)', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 700 }}>Item-by-Item Price Matrix</h3>
                <span style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>
                  {sortedQuotations.length} Bidding Supplier(s)
                </span>
              </div>

              <div className="table-container" style={{ overflowX: 'auto' }}>
                <table className="table" style={{ fontSize: '0.875rem', marginBottom: 0, width: '100%', tableLayout: 'fixed' }}>
                  <thead>
                    <tr>
                      <th style={{ width: '25%', backgroundColor: '#f8fafc', padding: '14px 16px', verticalAlign: 'middle' }}>Requested Product</th>
                      {sortedQuotations.map((q, idx) => {
                        const isL1 = idx === 0;
                        return (
                          <th 
                            key={q.int_Quotation_Id} 
                            style={{ 
                              textAlign: 'center', 
                              width: `${75 / Math.max(sortedQuotations.length, 1)}%`,
                              backgroundColor: '#f8fafc',
                              padding: '14px 16px',
                              borderLeft: '1px solid var(--color-border)',
                              verticalAlign: 'middle'
                            }}
                          >
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', minHeight: '62px', justifyContent: 'flex-end' }}>
                              <div style={{ height: '22px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                {isL1 ? (
                                  <span style={{ backgroundColor: '#2563eb', color: '#fff', fontSize: '0.65rem', fontWeight: 800, padding: '2px 8px', borderRadius: '10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                                    L1 Recommended
                                  </span>
                                ) : (
                                  <div style={{ height: '22px' }}></div>
                                )}
                              </div>
                              <div style={{ fontWeight: 800, fontSize: '0.95rem', color: 'var(--color-text-primary)', textAlign: 'center' }}>
                                {q.supplierName}
                              </div>
                              <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-purple-text)', backgroundColor: '#f3e8ff', padding: '1px 8px', borderRadius: '4px' }}>
                                {q.txt_Quotation_No || `QTN-${q.int_Quotation_Id}`}
                              </div>
                            </div>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>

                  <tbody>
                    {/* Item lines */}
                    {paginatedReqItems?.map((reqItem, idx) => {
                      const reqPId = Number(reqItem.int_Product_Id || reqItem.int_Item_Id);
                      const validPrices = sortedQuotations.map(q => {
                        const qItem = q.items?.find(i => Number(i.int_Product_Id || i.int_Item_Id) === reqPId);
                        const price = Number(qItem?.dec_Unit_Price ?? qItem?.dbl_Unit_Price ?? qItem?.unit_price ?? 0);
                        const isAvail = qItem && qItem.is_available !== false && qItem.txt_Status !== 'Not Available' && price > 0;
                        return isAvail ? price : Infinity;
                      });
                      const minUnitPrice = validPrices.length > 0 && validPrices.some(p => p !== Infinity) 
                        ? Math.min(...validPrices) 
                        : 0;

                      return (
                        <tr key={idx}>
                          <td style={{ padding: '12px 16px', fontWeight: 600, verticalAlign: 'middle' }}>
                            <div style={{ color: 'var(--color-text-primary)' }}>{reqItem.product_name || reqItem.txt_Item_Name}</div>
                            <div style={{ fontSize: '0.75rem', color: 'var(--color-text-secondary)', fontWeight: 500, marginTop: '2px' }}>
                              Req Qty: {reqItem.dec_Required_Qty || reqItem.int_Requested_Quantity || reqItem.int_Quantity || reqItem.quantity || 0} {reqItem.unit || reqItem.txt_Unit || 'Pcs'}
                            </div>
                          </td>

                          {sortedQuotations.map(q => {
                            const qItem = q.items?.find(i => Number(i.int_Product_Id || i.int_Item_Id) === reqPId);
                            const unitPrice = Number(qItem?.dec_Unit_Price ?? qItem?.dbl_Unit_Price ?? qItem?.unit_price ?? 0);
                            const isAvail = qItem && qItem.is_available !== false && qItem.txt_Status !== 'Not Available' && unitPrice > 0;
                            const isLowestPrice = isAvail && unitPrice === minUnitPrice && validPrices.filter(p => p !== Infinity).length > 1;

                            return (
                              <td 
                                key={q.int_Quotation_Id} 
                                style={{ 
                                  textAlign: 'center',
                                  padding: '10px 16px',
                                  verticalAlign: 'middle',
                                  borderLeft: '1px solid var(--color-border)',
                                  backgroundColor: 'transparent'
                                }}
                              >
                                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '46px' }}>
                                  {isAvail ? (
                                    <>
                                      <div style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--color-text-primary)', lineHeight: 1.2 }}>
                                        ₹{unitPrice.toFixed(2)} <span style={{ fontSize: '0.75rem', fontWeight: 500, color: 'var(--color-text-secondary)' }}>/ {reqItem.unit || 'Pcs'}</span>
                                      </div>
                                      <div style={{ height: '18px', marginTop: '3px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                        {isLowestPrice ? (
                                          <span style={{ fontSize: '0.65rem', backgroundColor: '#f1f5f9', color: '#0284c7', border: '1px solid #bae6fd', fontWeight: 700, padding: '2px 8px', borderRadius: '4px' }}>
                                            Lowest Item L1
                                          </span>
                                        ) : (
                                          <div style={{ height: '18px' }}></div>
                                        )}
                                      </div>
                                    </>
                                  ) : (
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '42px' }}>
                                      <span style={{ fontSize: '0.75rem', color: '#dc2626', fontWeight: 700, backgroundColor: '#fef2f2', border: '1px solid #fecaca', padding: '3px 8px', borderRadius: '4px' }}>
                                        Out of Stock
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })}

                    {/* Subtotal */}
                    <tr style={{ backgroundColor: '#f8fafc', fontWeight: 600 }}>
                      <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>Products Subtotal</td>
                      {sortedQuotations.map(q => (
                        <td key={q.int_Quotation_Id} style={{ textAlign: 'center', padding: '12px 16px', borderLeft: '1px solid var(--color-border)', verticalAlign: 'middle', fontWeight: 700 }}>
                          ₹{Number(q.itemsSubtotal || 0).toLocaleString('en-IN')}
                        </td>
                      ))}
                    </tr>

                    {/* Freight */}
                    <tr>
                      <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>Freight / Transport</td>
                      {sortedQuotations.map(q => (
                        <td key={q.int_Quotation_Id} style={{ textAlign: 'center', padding: '12px 16px', borderLeft: '1px solid var(--color-border)', verticalAlign: 'middle', fontWeight: 600 }}>
                          ₹{Number(q.transport || 0).toLocaleString('en-IN')}
                        </td>
                      ))}
                    </tr>

                    {/* Delivery Time */}
                    <tr>
                      <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>Delivery Turnaround</td>
                      {sortedQuotations.map(q => (
                        <td key={q.int_Quotation_Id} style={{ textAlign: 'center', padding: '12px 16px', borderLeft: '1px solid var(--color-border)', verticalAlign: 'middle', fontWeight: 600 }}>
                          {q.deliveryDays}
                        </td>
                      ))}
                    </tr>

                    {/* Grand Total */}
                    <tr style={{ backgroundColor: '#f1f5f9', fontWeight: 800, fontSize: '0.95rem' }}>
                      <td style={{ padding: '14px 16px', verticalAlign: 'middle' }}>Grand Total</td>
                      {sortedQuotations.map((q, idx) => (
                        <td 
                          key={q.int_Quotation_Id} 
                          style={{ 
                            textAlign: 'center', 
                            padding: '14px 16px',
                            borderLeft: '1px solid var(--color-border)',
                            color: 'var(--color-text-primary)',
                            fontSize: '1.05rem',
                            verticalAlign: 'middle'
                          }}
                        >
                          ₹{Number(q.grandTotal || 0).toLocaleString('en-IN')}
                        </td>
                      ))}
                    </tr>

                    {/* Action */}
                    <tr>
                      <td style={{ padding: '14px 16px', fontWeight: 800, verticalAlign: 'middle' }}>Action</td>
                      {sortedQuotations.map((q, idx) => (
                        <td key={q.int_Quotation_Id} style={{ textAlign: 'center', padding: '12px 16px', borderLeft: '1px solid var(--color-border)', verticalAlign: 'middle' }}>
                          {isOrderPlaced || q.txt_Status === 'Approved' ? (
                            <span style={{ color: '#059669', fontWeight: 800, fontSize: '0.85rem' }}>
                              ✓ PO Issued
                            </span>
                          ) : (
                            <button
                              className={idx === 0 ? "btn btn-primary" : "btn btn-secondary"}
                              onClick={() => handleAwardPO(q.int_Quotation_Id, q.supplierName)}
                              style={{ 
                                width: '100%', 
                                height: '38px',
                                justifyContent: 'center', 
                                fontWeight: 700, 
                                fontSize: '0.85rem',
                                padding: '0 12px',
                                borderRadius: '8px',
                                display: 'flex',
                                alignItems: 'center',
                                whiteSpace: 'nowrap'
                              }}
                            >
                              Accept Quote
                            </button>
                          )}
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Matrix Table Pagination */}
              <div style={{ 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'space-between', 
                padding: '12px 20px', 
                backgroundColor: 'var(--color-bg-secondary, #f8fafc)', 
                borderTop: '1px solid var(--color-border)',
                flexWrap: 'wrap',
                gap: '12px'
              }}>
                <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-secondary)' }}>
                  Showing <strong>{totalReqItems > 0 ? itemsStartIndex + 1 : 0} - {Math.min(itemsStartIndex + itemsPageSize, totalReqItems)}</strong> of <strong>{totalReqItems}</strong> products
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    disabled={itemsPage === 1}
                    onClick={() => setItemsPage(prev => Math.max(prev - 1, 1))}
                  >
                    <ChevronLeft size={14} /> Previous
                  </button>
                  <span style={{ fontSize: '0.8125rem', color: 'var(--color-text-secondary)', padding: '0 8px' }}>
                    Page <strong>{itemsPage}</strong> of <strong>{itemsTotalPages}</strong>
                  </span>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    disabled={itemsPage === itemsTotalPages}
                    onClick={() => setItemsPage(prev => Math.min(prev + 1, itemsTotalPages))}
                  >
                    Next <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* MODE 3: INDIVIDUAL QUOTE INSPECTOR */}
          {viewMode === 'inspector' && activeInspectorQuote && (
            <div className="card" style={{ padding: '24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <label className="form-label" style={{ margin: 0, fontWeight: 700 }}>Inspect Supplier Bid:</label>
                  <select
                    className="form-select"
                    style={{ minWidth: '260px', fontWeight: 600 }}
                    value={inspectorSupplierId || activeInspectorQuote.int_Supplier_Id}
                    onChange={e => setInspectorSupplierId(e.target.value)}
                  >
                    {sortedQuotations.map((q, idx) => (
                      <option key={q.int_Quotation_Id} value={q.int_Supplier_Id}>
                        {q.supplierName} ({idx === 0 ? 'L1 Recommended — ' : ''}₹{q.grandTotal.toLocaleString('en-IN')})
                      </option>
                    ))}
                  </select>
                </div>

                {!isOrderPlaced && (
                  <button
                    className="btn btn-success"
                    onClick={() => handleAwardPO(activeInspectorQuote.int_Quotation_Id, activeInspectorQuote.supplierName)}
                    style={{ fontWeight: 800 }}
                  >
                    Accept {activeInspectorQuote.supplierName}'s Quote
                  </button>
                )}
              </div>

              {/* Inspector Detailed Sheet */}
              <div style={{ border: '1px solid var(--color-border)', borderRadius: '10px', padding: '20px', backgroundColor: 'var(--color-surface)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--color-border)', paddingBottom: '14px', marginBottom: '14px' }}>
                  <div>
                    <h3 style={{ margin: 0, fontSize: '1.2rem', fontWeight: 800 }}>{activeInspectorQuote.supplierName}</h3>
                    <p style={{ margin: '2px 0 0 0', fontSize: '0.85rem', color: 'var(--color-text-secondary)' }}>
                      Quotation Code: <strong>{activeInspectorQuote.txt_Quotation_No || `QTN-${activeInspectorQuote.int_Quotation_Id}`}</strong>
                    </p>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '1.25rem', fontWeight: 900, color: 'var(--color-primary)' }}>
                      ₹{activeInspectorQuote.grandTotal.toLocaleString('en-IN')}
                    </div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)' }}>
                      Turnaround: {activeInspectorQuote.deliveryDays}
                    </div>
                  </div>
                </div>

                {/* Products Table */}
                <table className="table" style={{ fontSize: '0.85rem' }}>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Product Name</th>
                      <th>Req Qty</th>
                      <th>Quoted Unit Price</th>
                      <th>Subtotal</th>
                      <th>Stock Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      // Retrieve the exact request items associated with this quotation
                      const targetReq = (requests || []).find(r => Number(r.int_Request_Id) === Number(activeInspectorQuote.int_Request_Id));
                      const requestedItemsForQuote = (targetReq && targetReq.items && targetReq.items.length > 0)
                        ? targetReq.items
                        : (activeInspectorQuote.items && activeInspectorQuote.items.length > 0
                            ? activeInspectorQuote.items
                            : (currentReq?.items || []));

                      return requestedItemsForQuote.map((reqItem, idx) => {
                        const reqPId = Number(reqItem.int_Product_Id || reqItem.int_Item_Id);
                        const qItem = activeInspectorQuote.items?.find(i => Number(i.int_Product_Id || i.int_Item_Id) === reqPId);
                        const price = Number(qItem?.dec_Unit_Price ?? qItem?.dbl_Unit_Price ?? qItem?.unit_price ?? 0);
                        const isAvail = qItem && qItem.is_available !== false && qItem.txt_Status !== 'Not Available' && price > 0;
                        const reqQty = Number(reqItem.dec_Required_Qty || reqItem.int_Requested_Quantity || reqItem.int_Quantity || reqItem.quantity || 1);

                        return (
                          <tr key={idx}>
                            <td>{idx + 1}</td>
                            <td style={{ fontWeight: 600 }}>{reqItem.product_name || reqItem.txt_Item_Name}</td>
                            <td>{reqQty} {reqItem.unit || 'Pcs'}</td>
                            <td>{isAvail ? `₹${price.toFixed(2)}` : '—'}</td>
                            <td style={{ fontWeight: 700 }}>{isAvail ? `₹${(price * reqQty).toLocaleString('en-IN')}` : '—'}</td>
                            <td>
                              {isAvail ? (
                                <span style={{ color: '#059669', fontWeight: 700, backgroundColor: '#e6f4ea', border: '1px solid #a7f3d0', padding: '3px 10px', borderRadius: '4px', fontSize: '0.8rem' }}>
                                  Available
                                </span>
                              ) : (
                                <span style={{ color: '#dc2626', fontWeight: 700, backgroundColor: '#fef2f2', border: '1px solid #fecaca', padding: '3px 10px', borderRadius: '4px', fontSize: '0.8rem' }}>
                                  Not Available
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
