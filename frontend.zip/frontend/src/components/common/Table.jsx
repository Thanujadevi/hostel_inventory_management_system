import React, { useState, useEffect } from 'react';
import { Search, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { matchesWordPrefix } from '../../utils/searchUtils';
import { HighlightText } from './HighlightText';

export const Table = ({ 
  columns = [], 
  data = [], 
  isLoading = false,
  searchPlaceholder = "Search records...", 
  emptyMessage = "No data found",
  pageSize = 5,
  showSearch = true,
  externalSearchTerm = null
}) => {
  const dataContext = useData();
  const contextLoading = dataContext?.loading || false;
  const isDataLoading = isLoading || contextLoading;

  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const activeSearchTerm = externalSearchTerm !== null ? externalSearchTerm : searchTerm;
  const safeData = Array.isArray(data) ? data : [];

  const filteredData = safeData.filter(row => {
    if (!row) return false;
    return matchesWordPrefix(row, activeSearchTerm);
  });

  // Reset to page 1 when search term changes or data length changes
  useEffect(() => {
    setCurrentPage(1);
  }, [activeSearchTerm, safeData.length]);

  // Pagination calculation (5 items per page)
  const totalPages = Math.ceil(filteredData.length / pageSize) || 1;
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedData = filteredData.slice(startIndex, startIndex + pageSize);

  return (
    <div>
      {/* Search Header */}
      {showSearch && (
        <div style={{ marginBottom: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
          <div style={{ position: 'relative', width: '320px' }}>
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-muted)' }} />
            <input
              type="text"
              className="form-control"
              style={{ paddingLeft: '36px' }}
              placeholder={searchPlaceholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-secondary)' }}>
            Showing <strong>{filteredData.length > 0 ? startIndex + 1 : 0} - {Math.min(startIndex + pageSize, filteredData.length)}</strong> of {filteredData.length} items
          </div>
        </div>
      )}

      {/* Table Container */}
      <div className="table-container">
        <table className="table">
          <thead>
            <tr>
              {columns.map((col, idx) => (
                <th key={idx} style={{ width: col.width || 'auto', textAlign: col.align || 'left' }}>
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isDataLoading && safeData.length === 0 ? (
              <tr>
                <td colSpan={columns.length} style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--color-text-secondary)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}>
                    <Loader2 size={18} className="spin-animation" style={{ animation: 'spin 1s linear infinite', color: 'var(--color-primary)' }} />
                    <span style={{ fontWeight: 600, fontSize: '0.9rem', color: 'var(--color-text-primary)' }}>Loading records from database...</span>
                  </div>
                </td>
              </tr>
            ) : paginatedData.length === 0 ? (
              <tr>
                <td colSpan={columns.length} style={{ textAlign: 'center', padding: '36px 20px', color: 'var(--color-text-secondary)' }}>
                  <div style={{ fontWeight: 600, fontSize: '0.95rem', color: 'var(--color-text-primary)' }}>{emptyMessage}</div>
                </td>
              </tr>
            ) : (
              paginatedData.map((row, rowIdx) => (
                <tr key={rowIdx}>
                  {columns.map((col, colIdx) => (
                    <td key={colIdx} style={{ textAlign: col.align || 'left' }}>
                      {col.render ? col.render(row, activeSearchTerm) : <HighlightText text={row[col.accessor]} query={activeSearchTerm} />}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Always Render Pagination Controls */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid var(--color-border)' }}>
        <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-secondary)' }}>
          Page <strong>{currentPage}</strong> of <strong>{totalPages}</strong>
        </div>

        <div style={{ display: 'flex', gap: '6px' }}>
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            style={{ display: 'flex', alignItems: 'center', gap: '4px', opacity: currentPage === 1 ? 0.5 : 1 }}
          >
            <ChevronLeft size={14} /> Previous
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1).map(pageNum => (
            <button
              key={pageNum}
              type="button"
              className={`btn btn-sm ${currentPage === pageNum ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setCurrentPage(pageNum)}
              style={{ minWidth: '32px', padding: '4px 8px' }}
            >
              {pageNum}
            </button>
          ))}

          <button
            type="button"
            className="btn btn-secondary btn-sm"
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            style={{ display: 'flex', alignItems: 'center', gap: '4px', opacity: currentPage === totalPages ? 0.5 : 1 }}
          >
            Next <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
