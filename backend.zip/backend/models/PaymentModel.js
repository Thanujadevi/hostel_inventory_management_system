import pool from '../config/db.js';
import { getOrGenerateUniqueCode } from '../utils/codeUtils.js';

export const PaymentModel = {
  async getAll() {
    const [rows] = await pool.query(`
      SELECT pay.*, 
             COALESCE(pay.txt_Payment_Code, CONCAT('PAY-', LPAD(pay.int_Payment_Id, 3, '0'))) AS txt_Payment_No,
             pay.dbl_Amount AS dec_Payment_Amount,
             pay.txt_Status AS txt_Payment_Status,
             pay.txt_Transaction_Ref AS txt_Transaction_Id,
             COALESCE(p.txt_PO_Code, CONCAT('PO-2026-', LPAD(p.int_Purchase_Id, 3, '0'))) AS po_number, 
             s.txt_Supplier_Name AS supplier_name 
      FROM tbl_Payment pay
      LEFT JOIN tbl_Purchase p ON pay.int_Purchase_Id = p.int_Purchase_Id
      LEFT JOIN tbl_Supplier s ON p.int_Supplier_Id = s.int_Supplier_Id
      ORDER BY pay.int_Payment_Id DESC
    `);
    return rows;
  },

  async findById(id) {
    const [rows] = await pool.query('SELECT * FROM tbl_Payment WHERE int_Payment_Id = ?', [id]);
    return rows[0] || null;
  },

  async create(payData) {
    const paymentCode = await getOrGenerateUniqueCode(pool, 'tbl_Payment', 'txt_Payment_Code', 'PAY', payData.txt_Payment_Code);
    const createdBy = payData.txt_Created_By || 'Chief Warden / Admin';
    const updatedBy = payData.txt_Updated_By || createdBy;

    const [result] = await pool.query(
      `INSERT INTO tbl_Payment
        (txt_Payment_Code, int_Purchase_Id, dbl_Amount, txt_Payment_Mode, txt_Transaction_Ref, dte_Payment_Date, txt_Status, dte_Created_Date, txt_Created_By, dte_Updated_Date, txt_Updated_By)
      VALUES (?, ?, ?, ?, ?, NOW(), ?, NOW(), ?, NOW(), ?)`,
      [
        paymentCode, payData.int_Purchase_Id || 1,
        payData.dbl_Amount || payData.amount || 0, payData.txt_Payment_Mode || 'Bank Transfer',
        payData.txt_Transaction_Ref || '', payData.txt_Status || 'Completed',
        createdBy, updatedBy
      ]
    );

    if (payData.int_Purchase_Id) {
      await pool.query(
        'UPDATE tbl_Purchase SET txt_Status = "Completed", dte_Updated_Date = NOW(), txt_Updated_By = ? WHERE int_Purchase_Id = ?',
        [updatedBy, payData.int_Purchase_Id]
      );
    }

    return this.findById(result.insertId);
  }
};
